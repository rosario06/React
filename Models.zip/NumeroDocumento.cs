﻿using System;
using System.Collections.Generic;

namespace CoreVentas.Models;

public partial class NumeroDocumento
{
    public int Id { get; set; }

    public DateTime? FechaRegistro { get; set; }
}
