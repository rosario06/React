﻿namespace CoreVentas.Models.DTO
{
    public class DtoHistoriaVenta
    {
        public string FechaRegistro { get; set; }
        public string NumeroDocunto { get; set; }
        public string TipoDocumento { get; set; }
        public string DocumentoCliente { get; set; }
        public string NombreCliente { get; set; }
        public string UsuaioRegistro { get; set; }
        public string SubTotalo { get; set; }
        public string Impuesto { get; set; }
        public string Total { get; set; }

        public List<DtoDetalleVenta> Detalle { get; set; }
    }
}
