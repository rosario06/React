﻿namespace CoreVentas.Models.DTO
{
    public class Dtosesion
    {
        public string correo { get; set; }
        public string clave { get; set; }
    }
}
