﻿namespace CoreVentas.Models.DTO
{
    public class DtoVentasDias
    {
        public string Fecha { get; set; }
        public string Total { get; set; }
    }
}
