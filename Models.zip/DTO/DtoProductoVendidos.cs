﻿namespace CoreVentas.Models.DTO
{
    public class DtoProductoVendidos
    {
        public string Producto { get; set; }
        public string Total { get; set;}
    }
}
